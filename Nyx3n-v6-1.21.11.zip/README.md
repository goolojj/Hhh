# NYX3N v6 — Smooth Pro Edition (Minecraft 1.21.11 Fabric)

## What's New in NYX3N v6
- **Silky-Smooth Aim & Movement Interpolation**: No more violent 1-tick camera snapping or stuttery movement! Smooth yaw/pitch interpolation (`smoothLookAt`) + movement hysteresis deadzones.
- **Proper NethPot Auto-Pot + Auto-Refill**:
  - 2-tick downward splash throw (rotates to feet first, THEN throws so 100% of healing hits you, then instantly returns to Sword!).
  - **Auto-Refill from Inventory**: Automatically quick-moves Splash Potions from inventory (`slots 9..35`) to hotbar when hotbar pots run low!
  - Never wastes time eating a Golden Apple while Splash Potions are available.
- **Build UHC Cobweb Water-Escape**: Instantly detects when you are stuck in a Cobweb (`Blocks.COBWEB`), places Water Bucket at feet to wash it away, and scoops the water back up!
- **True NethPot & Sword Crit Engine**: Reliable alternating Sprint W-Tap + Timed Jump-Crit chain even against fast Speed II opponents, plus smooth counter-strafe tracking and Combo Sneak-Tap.
- **Persistent Auto-Save Config (`config/nyx3n-client.json`)** + 1-Click Presets (`Build UHC`, `Sword/Pot`, `Crystal`, `Survival`).
