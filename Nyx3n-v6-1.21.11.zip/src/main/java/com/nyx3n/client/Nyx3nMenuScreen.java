package com.nyx3n.client;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.text.Text;

public class Nyx3nMenuScreen extends Screen {
    private int page = 0;

    public Nyx3nMenuScreen() {
        super(Text.literal("NYX3N v6 Smooth Menu"));
    }

    @Override
    public boolean shouldPause() {
        return false;
    }

    @Override
    protected void init() {
        super.init();
        rebuildButtons();
    }

    private void onToggleChanged(boolean nowOn) {
        Nyx3nConfig cfg = Nyx3nClientMod.getConfig();
        if (nowOn) cfg.masterEnabled = true;
        cfg.activePreset = "CUSTOM";
        cfg.save();
    }

    private void rebuildButtons() {
        this.clearChildren();
        Nyx3nConfig cfg = Nyx3nClientMod.getConfig();

        int totalW = 324;
        int leftX = this.width / 2 - totalW / 2;

        // Top 1-Click Presets Row
        int presetW = 78;
        int presetY = 34;
        this.addDrawableChild(ButtonWidget.builder(Text.literal("\u00A7eBuild UHC"), btn -> {
            cfg.applyBuildUhcPreset();
            rebuildButtons();
        }).dimensions(leftX, presetY, presetW, 18).build());

        this.addDrawableChild(ButtonWidget.builder(Text.literal("\u00A7bNethPot"), btn -> {
            cfg.applySwordPotPreset();
            rebuildButtons();
        }).dimensions(leftX + 82, presetY, presetW, 18).build());

        this.addDrawableChild(ButtonWidget.builder(Text.literal("\u00A7dCrystal"), btn -> {
            cfg.applyCrystalPreset();
            rebuildButtons();
        }).dimensions(leftX + 164, presetY, presetW, 18).build());

        this.addDrawableChild(ButtonWidget.builder(Text.literal("\u00A7aSurvival"), btn -> {
            cfg.applySurvivalPreset();
            rebuildButtons();
        }).dimensions(leftX + 246, presetY, presetW, 18).build());

        int colW = 158;
        int btnH = 18;
        int gapX = 8;
        int gapY = 3;
        int startY = 58;

        if (page == 0) {
            addToggle(leftX, startY, colW, btnH, "Player Retaliate", cfg.playerRetaliate, () -> {
                cfg.playerRetaliate = !cfg.playerRetaliate;
                onToggleChanged(cfg.playerRetaliate);
            });
            addToggle(leftX + colW + gapX, startY, colW, btnH, "Auto Combat", cfg.autoCombat, () -> {
                cfg.autoCombat = !cfg.autoCombat;
                onToggleChanged(cfg.autoCombat);
            });

            addToggle(leftX, startY + (btnH + gapY), colW, btnH, "Jump Reset", cfg.jumpReset, () -> {
                cfg.jumpReset = !cfg.jumpReset;
                onToggleChanged(cfg.jumpReset);
            });
            addToggle(leftX + colW + gapX, startY + (btnH + gapY), colW, btnH, "HT3 Crit+WTap", cfg.pCritWtap, () -> {
                cfg.pCritWtap = !cfg.pCritWtap;
                onToggleChanged(cfg.pCritWtap);
            });

            addToggle(leftX, startY + (btnH + gapY) * 2, colW, btnH, "Combo Sneak-Tap", cfg.comboSneakTap, () -> {
                cfg.comboSneakTap = !cfg.comboSneakTap;
                onToggleChanged(cfg.comboSneakTap);
            });
            addToggle(leftX + colW + gapX, startY + (btnH + gapY) * 2, colW, btnH, "Counter-Strafe", cfg.ht3CrowdStrafe, () -> {
                cfg.ht3CrowdStrafe = !cfg.ht3CrowdStrafe;
                onToggleChanged(cfg.ht3CrowdStrafe);
            });

            addToggle(leftX, startY + (btnH + gapY) * 3, colW, btnH, "Auto-Shield", cfg.autoShield, () -> {
                cfg.autoShield = !cfg.autoShield;
                onToggleChanged(cfg.autoShield);
            });
            addToggle(leftX + colW + gapX, startY + (btnH + gapY) * 3, colW, btnH, "Auto-Pot+Refill", cfg.autoPotGap, () -> {
                cfg.autoPotGap = !cfg.autoPotGap;
                onToggleChanged(cfg.autoPotGap);
            });

            addToggle(leftX, startY + (btnH + gapY) * 4, colW, btnH, "Build UHC Kit", cfg.buildUhcKit, () -> {
                cfg.buildUhcKit = !cfg.buildUhcKit;
                onToggleChanged(cfg.buildUhcKit);
            });
            addToggle(leftX + colW + gapX, startY + (btnH + gapY) * 4, colW, btnH, "Crystal PvP", cfg.crystalPvp, () -> {
                cfg.crystalPvp = !cfg.crystalPvp;
                onToggleChanged(cfg.crystalPvp);
            });
        } else {
            addToggle(leftX, startY, colW, btnH, "Auto-Totem", cfg.autoTotem, () -> {
                cfg.autoTotem = !cfg.autoTotem;
                cfg.save();
            });
            addToggle(leftX + colW + gapX, startY, colW, btnH, "Anti-Creeper 12m", cfg.antiCreeper, () -> {
                cfg.antiCreeper = !cfg.antiCreeper;
                cfg.save();
            });

            addToggle(leftX, startY + (btnH + gapY), colW, btnH, "Tree Chopper", cfg.treeChopper, () -> {
                cfg.treeChopper = !cfg.treeChopper;
                onToggleChanged(cfg.treeChopper);
            });
            addToggle(leftX + colW + gapX, startY + (btnH + gapY), colW, btnH, "Auto Mining", cfg.autoMining, () -> {
                cfg.autoMining = !cfg.autoMining;
                onToggleChanged(cfg.autoMining);
            });

            addToggle(leftX, startY + (btnH + gapY) * 2, colW, btnH, "Build House", cfg.buildHouse, () -> {
                cfg.buildHouse = !cfg.buildHouse;
                if (cfg.buildHouse) Nyx3nClientMod.getEngine().resetHousePlan();
                onToggleChanged(cfg.buildHouse);
            });
            addToggle(leftX + colW + gapX, startY + (btnH + gapY) * 2, colW, btnH, "Golem 3-Block", cfg.ironGolemCheese, () -> {
                cfg.ironGolemCheese = !cfg.ironGolemCheese;
                onToggleChanged(cfg.ironGolemCheese);
            });

            addToggle(leftX, startY + (btnH + gapY) * 3, colW, btnH, "Auto-Eat", cfg.autoEat, () -> {
                cfg.autoEat = !cfg.autoEat;
                cfg.save();
            });
            addToggle(leftX + colW + gapX, startY + (btnH + gapY) * 3, colW, btnH, "Auto-Tool", cfg.autoTool, () -> {
                cfg.autoTool = !cfg.autoTool;
                cfg.save();
            });

            this.addDrawableChild(ButtonWidget.builder(
                    Text.literal("HUD: " + cfg.getHudPositionLabel()),
                    btn -> {
                        cfg.cycleHudPosition();
                        rebuildButtons();
                    }
            ).dimensions(leftX, startY + (btnH + gapY) * 4, colW, btnH).build());

            this.addDrawableChild(ButtonWidget.builder(
                    Text.literal("\u00A7cPANIC STOP ALL"),
                    btn -> {
                        cfg.panicStopAll();
                        if (this.client != null) Nyx3nClientMod.getEngine().forceStop(this.client);
                        rebuildButtons();
                    }
            ).dimensions(leftX + colW + gapX, startY + (btnH + gapY) * 4, colW, btnH).build());
        }

        int navY = startY + (btnH + gapY) * 5 + 6;
        this.addDrawableChild(ButtonWidget.builder(
                Text.literal(page == 0 ? "Page 2: Survival & Totem ->" : "<- Page 1: PvP & Kits"),
                btn -> {
                    page = (page == 0) ? 1 : 0;
                    rebuildButtons();
                }
        ).dimensions(leftX, navY, 212, 18).build());

        this.addDrawableChild(ButtonWidget.builder(
                Text.literal("\u00A7aSave & Close"),
                btn -> {
                    cfg.save();
                    this.close();
                }
        ).dimensions(leftX + 218, navY, 106, 18).build());
    }

    private void addToggle(int x, int y, int w, int h, String name, boolean state, Runnable action) {
        String label = name + ": " + (state ? "\u00A7aON" : "\u00A7cOFF");
        this.addDrawableChild(ButtonWidget.builder(Text.literal(label), btn -> {
            action.run();
            rebuildButtons();
        }).dimensions(x, y, w, h).build());
    }

    @Override
    public void renderBackground(DrawContext context, int mouseX, int mouseY, float delta) {
        super.renderBackground(context, mouseX, mouseY, delta);
        Nyx3nConfig cfg = Nyx3nClientMod.getConfig();
        int panelW = 342;
        int panelH = 186;
        int px = this.width / 2 - panelW / 2;
        int py = 12;

        context.fill(px - 2, py - 2, px + panelW + 2, py + panelH + 2, 0xFF10F5A8);
        context.fill(px, py, px + panelW, py + panelH, 0xE8081118);

        String header = "NYX3N v6 Smooth  |  Preset: " + cfg.activePreset + "  |  Auto-Save";
        context.drawCenteredTextWithShadow(this.textRenderer, header, this.width / 2, py + 8, 0xFF34F5C5);
    }
}
