package com.nyx3n.client;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import net.fabricmc.loader.api.FabricLoader;

import java.nio.file.Files;
import java.nio.file.Path;

public class Nyx3nConfig {
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static final Path CONFIG_PATH = FabricLoader.getInstance()
            .getConfigDir()
            .resolve("nyx3n-client.json");

    public boolean masterEnabled = true;
    public String activePreset = "CUSTOM";

    // Page 1: PvP & Combat
    public boolean playerRetaliate = true;
    public boolean autoCombat = true;
    public boolean jumpReset = true;
    public boolean pCritWtap = true;
    public boolean comboSneakTap = true;
    public boolean ht3CrowdStrafe = true;
    public boolean autoShield = true;
    public boolean autoPotGap = true;
    public boolean buildUhcKit = false;
    public boolean crystalPvp = false;

    // Page 2: Survival & Utilities
    public boolean autoTotem = true;
    public boolean antiCreeper = true;
    public boolean treeChopper = false;
    public boolean autoMining = false;
    public boolean buildHouse = false;
    public boolean ironGolemCheese = false;
    public boolean autoEat = true;
    public boolean autoTool = true;
    public boolean autoCollectDrops = true;
    public boolean autoSprint = true;
    public boolean autoJump = true;
    public boolean waterRescue = true;
    public boolean lowHpRetreat = false;
    public boolean leafCleaner = true;
    public boolean mobRadarHud = true;
    public boolean nightAlert = true;

    public int hudPosition = 0;

    public String getHudPositionLabel() {
        return switch (hudPosition) {
            case 0 -> "TOP-RIGHT";
            case 1 -> "TOP-CENTER";
            default -> "TOP-LEFT";
        };
    }

    public void cycleHudPosition() {
        hudPosition = (hudPosition + 1) % 3;
        save();
    }

    public void applyBuildUhcPreset() {
        masterEnabled = true;
        activePreset = "BUILD UHC";
        playerRetaliate = true;
        autoCombat = true;
        jumpReset = true;
        pCritWtap = true;
        comboSneakTap = true;
        ht3CrowdStrafe = true;
        autoShield = true;
        autoPotGap = true;
        buildUhcKit = true;
        crystalPvp = false;
        autoTotem = true;
        treeChopper = false;
        autoMining = false;
        buildHouse = false;
        ironGolemCheese = false;
        save();
    }

    public void applySwordPotPreset() {
        masterEnabled = true;
        activePreset = "NETHPOT/SWORD";
        playerRetaliate = true;
        autoCombat = true;
        jumpReset = true;
        pCritWtap = true;
        comboSneakTap = true;
        ht3CrowdStrafe = true;
        autoShield = true;
        autoPotGap = true;
        buildUhcKit = false;
        crystalPvp = false;
        autoTotem = true;
        treeChopper = false;
        autoMining = false;
        buildHouse = false;
        ironGolemCheese = false;
        save();
    }

    public void applyCrystalPreset() {
        masterEnabled = true;
        activePreset = "CRYSTAL";
        playerRetaliate = true;
        autoCombat = true;
        jumpReset = true;
        pCritWtap = true;
        comboSneakTap = false;
        ht3CrowdStrafe = true;
        autoShield = false;
        autoPotGap = true;
        buildUhcKit = false;
        crystalPvp = true;
        autoTotem = true;
        treeChopper = false;
        autoMining = false;
        buildHouse = false;
        ironGolemCheese = false;
        save();
    }

    public void applySurvivalPreset() {
        masterEnabled = true;
        activePreset = "SURVIVAL";
        playerRetaliate = true;
        autoCombat = true;
        jumpReset = true;
        pCritWtap = true;
        comboSneakTap = false;
        ht3CrowdStrafe = true;
        autoShield = true;
        autoPotGap = false;
        buildUhcKit = false;
        crystalPvp = false;
        autoTotem = true;
        antiCreeper = true;
        treeChopper = true;
        autoMining = false;
        buildHouse = false;
        autoEat = true;
        autoTool = true;
        save();
    }

    public void panicStopAll() {
        masterEnabled = false;
        activePreset = "STOPPED";
        treeChopper = false;
        autoMining = false;
        buildHouse = false;
        autoCombat = false;
        playerRetaliate = false;
        buildUhcKit = false;
        crystalPvp = false;
        ironGolemCheese = false;
        save();
    }

    public void save() {
        try {
            Files.createDirectories(CONFIG_PATH.getParent());
            Files.writeString(CONFIG_PATH, GSON.toJson(this));
        } catch (Exception ignored) {
        }
    }

    public static Nyx3nConfig load() {
        try {
            if (Files.exists(CONFIG_PATH)) {
                String json = Files.readString(CONFIG_PATH);
                Nyx3nConfig loaded = GSON.fromJson(json, Nyx3nConfig.class);
                if (loaded != null) {
                    return loaded;
                }
            }
        } catch (Exception ignored) {
        }
        Nyx3nConfig fresh = new Nyx3nConfig();
        fresh.save();
        return fresh;
    }
}
